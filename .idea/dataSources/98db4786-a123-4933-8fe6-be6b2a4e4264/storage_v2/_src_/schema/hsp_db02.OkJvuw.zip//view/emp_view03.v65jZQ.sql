create view emp_view03 as
select `hsp_db02`.`emp`.`empno`      AS `empno`,
       `hsp_db02`.`emp`.`ename`      AS `ename`,
       `hsp_db02`.`dept`.`dname`     AS `dname`,
       `hsp_db02`.`salgrade`.`grade` AS `grade`
from `hsp_db02`.`emp`
         join `hsp_db02`.`dept`
         join `hsp_db02`.`salgrade`
where ((`hsp_db02`.`emp`.`deptno` = `hsp_db02`.`dept`.`deptno`) and
       (`hsp_db02`.`emp`.`sal` between `hsp_db02`.`salgrade`.`losal` and `hsp_db02`.`salgrade`.`hisal`));

