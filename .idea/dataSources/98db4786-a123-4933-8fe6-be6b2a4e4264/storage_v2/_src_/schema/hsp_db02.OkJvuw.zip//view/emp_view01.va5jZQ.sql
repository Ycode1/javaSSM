create view emp_view01 as
select `hsp_db02`.`emp`.`empno`  AS `empno`,
       `hsp_db02`.`emp`.`ename`  AS `ename`,
       `hsp_db02`.`emp`.`job`    AS `job`,
       `hsp_db02`.`emp`.`deptno` AS `deptno`
from `hsp_db02`.`emp`;

