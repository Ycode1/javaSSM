create view emp_view02 as
select `emp_view01`.`empno` AS `empno`, `emp_view01`.`ename` AS `ename`
from `hsp_db02`.`emp_view01`;

